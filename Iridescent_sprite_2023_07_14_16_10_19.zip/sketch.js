// rock:  U+1FAA8
// paper: U+1F4C3
// scissors: U+2702
//var emoji = String.fromCodePoint(0x1F621)

var canvasSize = 800;
var numItems = 21;
var r = 10;
var d = r * 2;

let emoji_dict = { r: "0x1FAA8", p: "0x1F4C3", s: "0x2702" };

class emoji {
  constructor(x, y, xSpeed, ySpeed, emoji) {
    this.x = x;
    this.y = y;
    this.xSpeed = xSpeed;
    this.ySpeed = ySpeed;
    this.emoji = emoji;
    this.emoji_code = emoji_dict[emoji];
  }

  move() {
    this.x += this.xSpeed;
    if (this.x < 0 || this.x > canvasSize) {
      this.reverseX();
      // this.xSpeed *= -1;
    }

    this.y += this.ySpeed;
    if (this.y < 0 || this.y > canvasSize) {
      this.reverseY();
      //this.ySpeed *= -1;
    }
  }

  reverseX() {
    this.xSpeed *= -1;
  }

  reverseY() {
    this.ySpeed *= -1;
  }

  intersects(other) {
    //console.log("KaPOW!");
    // this.xSpeed *= -1;
    // this.ySpeed *= -1;
    // other.xSpeed *= -1;
    // other.ySpeed *= -1;
    return dist(this.x, this.y, other.x, other.y) < d;
  }

  fight(other) {
    if (this.emoji == "s") {
      if (other.emoji == "r") {
        this.emoji = "r";
        this.emoji_code = emoji_dict["r"];
      } else if (other.emoji == "p") {
        other.emoji = "s";
        other.emoji_code = emoji_dict["s"];
      }
    } else if (this.emoji == "p") {
      if (other.emoji == "s") {
        this.emoji = "s";
        this.emoji_code = emoji_dict["s"];
      } else if (other.emoji == "r") {
        other.emoji = "p";
        other.emoji_code = emoji_dict["p"];
      }
    } else {
      if (other.emoji == "p") {
        this.emoji = "p";
        this.emoji_code = emoji_dict["p"];
      } else if (other.emoji == "s") {
        other.emoji = "r";
        other.emoji_code = emoji_dict["r"];
      }
    }
  }

  display() {
    circle(this.x, this.y, d);
    text(
      String.fromCodePoint(this.emoji_code),
      this.x - r,
      this.y + Math.floor(d / 3)
    );
  }
}

let emojis = [];

function setup() {
  createCanvas(canvasSize, canvasSize);
  for (let i = 0; i < numItems; i++) {
    var em = "r";
    if (i < Math.floor(numItems / 3)) {
      em = "r";
    } else if (i < Math.floor((numItems * 2) / 3)) {
      em = "p";
    } else {
      em = "s";
    }
    let n = new emoji(
      Math.floor(Math.random() * canvasSize),
      Math.floor(Math.random() * canvasSize),
      Math.random() / 5,
      Math.random() / 5,
      em
    );
    emojis.push(n);
    //console.log(n.xSpeed);
  }
}

function draw() {
  background(1000);
  for (let i = 0; i < emojis.length; i++) {
    for (let j = i + 1; j < emojis.length; j++) {
      if (emojis[i].intersects(emojis[j])) {
        emojis[i].reverseX();
        emojis[i].reverseY();
        emojis[j].reverseX();
        emojis[j].reverseY();
        emojis[i].fight(emojis[j]);
      }
      emojis[i].move();
      noStroke();
      textSize(20);
      emojis[i].display();
    }
  }
}
